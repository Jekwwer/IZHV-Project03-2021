﻿using System;
using Unity.Entities;

/// <summary>
/// Tag for enemies.
/// </summary>
[Serializable]
public struct TEnemy : IComponentData 
{ /* Empty */ }
