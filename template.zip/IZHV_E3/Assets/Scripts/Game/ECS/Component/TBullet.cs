using System;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;

/// <summary>
/// Tag for bullets.
/// </summary>
[Serializable]
public struct TBullet : IComponentData 
{ /* Empty */ }
