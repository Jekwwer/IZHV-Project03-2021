﻿using System;
using Unity.Entities;

/// <summary>
/// Tag for entities moving forward.
/// </summary>
[Serializable]
public struct TMoveForward : IComponentData
{ /* Empty */ }
