﻿using System;
using Unity.Entities;

/// <summary>
/// Tag for players.
/// </summary>
[Serializable]
public struct TPlayer : IComponentData 
{ /* Empty */ }